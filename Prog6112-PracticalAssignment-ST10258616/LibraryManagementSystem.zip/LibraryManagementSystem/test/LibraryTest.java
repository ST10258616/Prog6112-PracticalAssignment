import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LibraryTest {
    private Library library;

    @BeforeEach
    public void setUp() {
        library = new Library();
    }

    @Test
    public void testAddBook() {
        Books book = new Books("Title1", "Author1", "12345");
        library.addBook(book);
        assertEquals(1, library.searchBooks("Title1").size());
    }

    @Test
    public void testSearchBooks() {
        Books book1 = new Books("Title1", "Author1", "12345");
        Books book2 = new Books("Title2", "Author2", "67890");
        library.addBook(book1);
        library.addBook(book2);
        assertEquals(1, library.searchBooks("Title1").size());
        assertEquals(1, library.searchBooks("Author2").size());
        assertEquals(0, library.searchBooks("Nonexistent").size());
    }

    @Test
    public void testGenerateReport() {
        Books book = new Books("Title1", "Author1", "12345");
        library.addBook(book);
        // Add code to capture and verify console output, if needed
        // This might involve redirecting System.out or using a testing library
    }
}
