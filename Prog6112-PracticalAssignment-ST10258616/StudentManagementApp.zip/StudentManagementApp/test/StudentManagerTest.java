import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class StudentManagerTest {
    private StudentManager manager;

    @BeforeEach
    public void setUp() {
        manager = new StudentManager();
    }

    // Helper method to simulate user input
    private void simulateInput(String input) {
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
    }

    @Test
    public void testSaveStudent() {
        simulateInput("101\nJohn Doe\n20\njohn.doe@example.com\nCS\n");
        manager.saveStudent();
        assertEquals(1, manager.getStudents().size());
        assertEquals("101", manager.getStudents().get(0).getId());
        assertEquals("John Doe", manager.getStudents().get(0).getName());
        assertEquals(20, manager.getStudents().get(0).getAge());
        assertEquals("john.doe@example.com", manager.getStudents().get(0).getEmail());
        assertEquals("CS", manager.getStudents().get(0).getCourse());
    }

    @Test
    public void testSearchStudent() {
        simulateInput("101\n");
        manager.saveStudent();
        simulateInput("101\n");
        manager.searchStudent();
        assertTrue(outContent.toString().contains("ID: 101"));
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        simulateInput("999\n");
        manager.searchStudent();
        assertTrue(outContent.toString().contains("Student cannot be located."));
    }

    @Test
    public void testDeleteStudent() {
        simulateInput("101\nJohn Doe\n20\njohn.doe@example.com\nCS\n");
        manager.saveStudent();
        simulateInput("101\nyes\n");
        manager.deleteStudent();
        assertEquals(0, manager.getStudents().size());
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        simulateInput("999\nno\n");
        manager.deleteStudent();
        assertTrue(outContent.toString().contains("Student cannot be located."));
    }

    @Test
    public void testStudentAge_StudentAgeValid() {
        simulateInput("101\nJohn Doe\n20\njohn.doe@example.com\nCS\n");
        manager.saveStudent();
        assertEquals(20, manager.getStudents().get(0).getAge());
    }

    @Test
    public void testStudentAge_StudentAgeInvalid() {
        simulateInput("101\nJohn Doe\n15\njohn.doe@example.com\nCS\n");
        manager.saveStudent();
        assertTrue(outContent.toString().contains("Age must be 16 or older."));
    }

    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        simulateInput("101\nJohn Doe\nabc\njohn.doe@example.com\nCS\n");
        manager.saveStudent();
        assertTrue(outContent.toString().contains("Please enter a valid number."));
    }
}
