import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<Books> books;

    // Constructor
    public Library() {
        books = new ArrayList<>();
    }

    // Add a new book
    public void addBook(Books book) {
        books.add(book);
    }

    // Search for books by title or author
    public List<Books> searchBooks(String query) {
        List<Books> result = new ArrayList<>();
        for (Books book : books) {
            if (book.getTitle().contains(query) || book.getAuthor().contains(query)) {
                result.add(book);
            }
        }
        return result;
    }

    // Generate a report of all books
    public void generateReport() {
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            for (Books book : books) {
                System.out.println(book);
            }
        }
    }
}
