import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;
    
    // Constructor
    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }
    
    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getEmail() { return email; }
    public String getCourse() { return course; }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age + ", Email: " + email + ", Course: " + course;
    }
}

class StudentManager {
    private ArrayList<Student> students = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    
    // Method to add a student
    public void saveStudent() {
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        
        int age;
        while (true) {
            System.out.print("Enter student age (must be >= 16): ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) break;
                else System.out.println("Age must be 16 or older.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }

        System.out.print("Enter student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter student course: ");
        String course = scanner.nextLine();

        students.add(new Student(id, name, age, email, course));
        System.out.println("Student details have been successfully saved.");
    }

    // Method to search for a student by ID
    public void searchStudent() {
        System.out.print("Enter student ID to search: ");
        String id = scanner.nextLine();
        boolean found = false;
        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println(student);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student cannot be located.");
        }
    }

    // Method to delete a student by ID
    public void deleteStudent() {
        System.out.print("Enter student ID to delete: ");
        String id = scanner.nextLine();
        boolean found = false;
        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.print("Are you sure you want to delete this student? (yes/no): ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("yes")) {
                    students.remove(student);
                    System.out.println("Student deleted successfully.");
                } else {
                    System.out.println("Deletion cancelled.");
                }
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student cannot be located.");
        }
    }

    // Method to display student report
    public void studentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            System.out.println("Student Report:");
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }

    // Method to exit the application
    public void exitStudentApplication() {
        System.out.println("Exiting application...");
        System.exit(0);
    }
}
