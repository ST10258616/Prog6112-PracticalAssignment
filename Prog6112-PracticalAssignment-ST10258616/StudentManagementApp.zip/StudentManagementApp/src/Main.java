import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        StudentManager manager = new StudentManager();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\nABC College Student Management System");
            System.out.println("1. Capture a New Student");
            System.out.println("2. Search for a Student");
            System.out.println("3. Delete a Student");
            System.out.println("4. View Student Report");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid option. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    manager.saveStudent();
                    break;
                case 2:
                    manager.searchStudent();
                    break;
                case 3:
                    manager.deleteStudent();
                    break;
                case 4:
                    manager.studentReport();
                    break;
                case 5:
                    manager.exitStudentApplication();
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
