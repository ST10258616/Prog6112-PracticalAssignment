import java.util.Scanner;

public class LibraryApp {
    private static Library library = new Library();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add a New Book");
            System.out.println("2. Search for a Book");
            System.out.println("3. Generate Report");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter ISBN: ");
                    String isbn = scanner.nextLine();
                    library.addBook(new Books(title, author, isbn));
                    System.out.println("Book added successfully.");
                    break;
                case 2:
                    System.out.print("Enter title or author to search: ");
                    String query = scanner.nextLine();
                    System.out.println("Search Results:");
                    for (Books book : library.searchBooks(query)) {
                        System.out.println(book);
                    }
                    break;
                case 3:
                    System.out.println("Library Report:");
                    library.generateReport();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
